#!/bin/bash

curl -sL  https://raw.githubusercontent.com/nineasku55/tampung/refs/heads/main/ver555 | bash