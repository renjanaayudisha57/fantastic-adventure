#!/bin/bash

chmod 777 install.sh && ./install.sh
