#!/bin/bash

MIN=$1; while true; do python3 python.py "$MIN"; sleep 10; done